# 🧳 Trip Planner

A cozy, self-hosted website for planning trips with your friends. You run it on
your own Windows PC, log in, and add trips with itineraries, packing lists,
budgets, and booking links. **Only people you give an account to can see it.**

![editions](https://img.shields.io/badge/runs%20on-Node.js-339933) ![auth](https://img.shields.io/badge/access-friends%20only-ff8a5b)

---

## ✨ What you get

- **Pretty trip board, split into Upcoming and Past adventures** — each trip is a card with a colour theme, emoji, dates, and a live countdown.
- **Rich trip pages** — overview, day-by-day itinerary, packing checklist (tick items off live), budget, who's coming, links/bookings, and free-form notes.
- **Per-trip sharing** — when you create a trip you tick which friends can see it. Everyone only sees the trips shared with them (you, the owner, see all).
- **Add / edit everything in the browser** — no code needed once it's running.
- **Friends-only login** — passwords are hashed; the first account is the owner (you); friends join with an invite code.
- **On / off buttons** — `Start Trip Planner.bat` and `Stop Trip Planner.bat`.
- **Reachable on any network** — one click puts it online via a free Cloudflare Tunnel (`Go Online (any network).bat`), no router setup, no exposed home IP.
- **No database to install** — everything saves to a single `data/db.json` file.

---

## 🚀 Quick start (Windows)

1. **Install Node.js** (one time): get the **LTS** version from <https://nodejs.org> and run the installer.
2. **Double-click `Start Trip Planner.bat`.**
   - The first run installs dependencies automatically (needs internet).
   - A server window opens and your browser pops up at **http://localhost:4040**.
3. **Create your owner account.** The first account you make becomes the **owner** — no invite code needed.
4. Start adding trips with the **＋ New trip** button.
5. **To turn it off:** double-click **`Stop Trip Planner.bat`** (or just close the server window).

> Mac/Linux: run `npm install` then `npm start` in this folder.

---

## 👯 Letting your friends in

Your friends need two things:

1. **The invite code.** The default is `letmein` — **change it!** Edit (or create) a file
   called `.env` next to `server.js` containing:
   ```
   INVITE_CODE=our-secret-2026
   ```
   (See `.env.example`.) Then restart the server.
2. **Your computer's address on the network.** When the server starts, the window prints something like:
   ```
   On your network:   http://192.168.1.50:4040
   ```
   Give your friends that link. They open it, click **Create account**, and enter the invite code.

### Friends connecting from the same Wi-Fi
That `http://192.168.x.x:4040` link works for anyone on your home Wi-Fi.
The **first time**, Windows may ask to allow Node.js through the firewall — click **Allow** (Private networks).

### Friends connecting from ANY network (over the internet) ⭐
Double-click **`Go Online (any network).bat`** (while the server is running).

- The first run downloads a tiny helper (`cloudflared.exe`) automatically.
- It prints a public link like `https://shiny-forest-1234.trycloudflare.com`.
- **Share that link** with your friends — it works from anywhere, on any network,
  on phones too. They still need an account + invite code, so it stays private.
- It's free, needs **no router/port-forwarding**, and **doesn't expose your home IP**.
- Closing that window takes the site back offline.

> The `trycloudflare.com` address changes each time you start the tunnel. If you
> want a permanent custom address, you can set up a named Cloudflare Tunnel with a
> free Cloudflare account — see their
> [docs](https://developers.cloudflare.com/cloudflare-one/connections/connect-networks/).

---

## ✍️ Want me (Claude) to add your trips for you?

Just give me the trip details — past or upcoming — and I'll drop them straight into
the site. Tell me who each trip should be shared with and I'll set that too. Under
the hood that uses the importer:

```sh
node scripts/import-trips.js my-trips.json
```

See `trips.sample.json` for the format (a single trip object or an array of them).

- `startDate` / `endDate` decide whether a trip lands under **Upcoming** or **Past**.
- `allowedUsers` is a list of **usernames** allowed to see the trip (e.g. `["alex","sam"]`).
  Leave it out to share with everyone who has an account.

Re-running is safe — trips with the same title + start date are skipped. You can
always tweak them afterwards in the browser.

---

## ⚙️ Configuration

Everything has sensible defaults. To override, create a `.env` file (see `.env.example`):

| Variable      | Default   | What it does                              |
|---------------|-----------|-------------------------------------------|
| `PORT`        | `4040`    | Port the website runs on.                 |
| `INVITE_CODE` | `letmein` | Code friends enter once when registering. |

---

## 🗂️ Where your data lives

Everything is stored locally in the **`data/`** folder (which is git-ignored, so it
never gets committed or shared):

- `data/db.json` — your accounts and all trips.
- `data/sessions/` — keeps you logged in across restarts.
- `data/session.secret`, `data/server.pid` — internal.

**To back up**, copy the `data/` folder somewhere safe. To start fresh, delete it.

---

## 🔒 A note on security

This is a personal app for you and friends, not a hardened public service. It uses
hashed passwords, http-only session cookies, and an invite code, which is plenty for
a home setup. If you ever expose it to the open internet, put it behind HTTPS (a
tunnel or reverse proxy) rather than opening your router straight to it.

---

## 🛠️ Project layout

```
trip-planner/
├─ Start Trip Planner.bat        # on button
├─ Stop Trip Planner.bat         # off button
├─ Go Online (any network).bat   # publish via free Cloudflare Tunnel
├─ server.js                     # Express app
├─ lib/                          # config, JSON store, auth middleware
├─ routes/                       # /api/auth, /api/trips, /api/users
├─ public/                       # the website (HTML/CSS/JS)
├─ scripts/import-trips.js       # bulk-add trips from JSON
└─ data/                         # your saved data (auto-created, git-ignored)
```
