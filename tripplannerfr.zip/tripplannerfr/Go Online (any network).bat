@echo off
title Trip Planner - Go Online
cd /d "%~dp0"

echo.
echo  ==========================================================
echo    Putting your Trip Planner online (reachable anywhere)
echo  ==========================================================
echo.
echo  This uses a free Cloudflare Tunnel. No router setup, and it
echo  does NOT expose your home IP address.
echo.
echo  Make sure the server is already ON (run "Start Trip Planner.bat"
echo  first). Friends will still need an account + the invite code.
echo.

REM --- Get the cloudflared helper if we don't have it (one time) ----------
if not exist "cloudflared.exe" (
  echo  Downloading the Cloudflare Tunnel helper, please wait...
  powershell -Command "try { Invoke-WebRequest -UseBasicParsing -Uri 'https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-windows-amd64.exe' -OutFile 'cloudflared.exe' } catch { Write-Host $_; exit 1 }"
  if not exist "cloudflared.exe" (
    echo.
    echo  [!] Could not download it automatically.
    echo      Download "cloudflared-windows-amd64.exe" from:
    echo        https://github.com/cloudflare/cloudflared/releases/latest
    echo      Save it next to this file as "cloudflared.exe" and run again.
    echo.
    pause
    exit /b 1
  )
)

echo.
echo  Starting the tunnel. In a moment a public link will appear below,
echo  looking like:   https://something-random.trycloudflare.com
echo.
echo  ^>^>  Share THAT link with your friends.  ^<^<
echo.
echo  Closing this window takes the site offline again.
echo  ----------------------------------------------------------
echo.

cloudflared.exe tunnel --url http://localhost:4040

echo.
echo  Tunnel closed. Your site is no longer reachable from the internet.
pause
