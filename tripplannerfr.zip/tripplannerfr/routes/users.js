"use strict";

const express = require("express");
const db = require("../lib/db");
const { requireAuth } = require("../lib/auth-middleware");

const router = express.Router();
router.use(requireAuth);

// A lightweight directory of accounts, used to pick who a trip is shared with.
// Never exposes password hashes.
router.get("/", (req, res) => {
  const users = db.getUsers().map((u) => ({
    id: u.id,
    username: u.username,
    displayName: u.displayName,
    isAdmin: !!u.isAdmin,
  }));
  res.json({ users });
});

module.exports = router;
